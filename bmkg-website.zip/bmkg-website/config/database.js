const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

let db;
const dbPath = process.env.DB_PATH || './database/bmkg.db';

// Pastikan folder database ada
if (!fs.existsSync(path.dirname(dbPath))) {
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
}

async function getDatabase() {
    if (db) return db;
    
    const SQL = await initSqlJs();
    
    // Load existing DB or create new one
    let fileBuffer;
    try {
        fileBuffer = fs.readFileSync(dbPath);
        db = new SQL.Database(fileBuffer);
    } catch (e) {
        db = new SQL.Database();
    }

    // --- TABEL USERS (Admin/Staff) ---
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        nama_lengkap TEXT NOT NULL,
        email TEXT UNIQUE,
        nip TEXT UNIQUE,
        jabatan TEXT,
        role TEXT NOT NULL DEFAULT 'staff',
        unit_kerja TEXT,
        no_hp TEXT,
        is_active INTEGER DEFAULT 1,
        last_login DATETIME,
        failed_login_attempts INTEGER DEFAULT 0,
        locked_until DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // --- TABEL PUBLIKASI / BERITA ---
    db.run(`CREATE TABLE IF NOT EXISTS publications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        judul TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        kategori TEXT NOT NULL,
        ringkasan TEXT,
        konten TEXT NOT NULL,
        file_path TEXT,
        file_name TEXT,
        file_size INTEGER,
        author_id INTEGER,
        status TEXT DEFAULT 'draft',
        published_at DATETIME,
        view_count INTEGER DEFAULT 0,
        download_count INTEGER DEFAULT 0,
        tags TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // --- TABEL DATA IKLIM ---
    db.run(`CREATE TABLE IF NOT EXISTS climate_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tanggal DATE NOT NULL,
        stasiun TEXT NOT NULL,
        suhu_min REAL,
        suhu_max REAL,
        suhu_rata REAL,
        kelembaban_min REAL,
        kelembaban_max REAL,
        curah_hujan REAL,
        hari_hujan INTEGER,
        entered_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // --- TABEL MENU NAVIGASI DINAMIS (BARU) ---
    db.run(`CREATE TABLE IF NOT EXISTS menus (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        label TEXT NOT NULL,
        link TEXT DEFAULT '#',
        parent_id INTEGER DEFAULT 0,
        sort_order INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // --- TABEL PROFIL INSTANSI (BARU) ---
    db.run(`CREATE TABLE IF NOT EXISTS profile_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        section TEXT UNIQUE NOT NULL, -- e.g., 'visi_misi', 'sejarah'
        content TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // --- TABEL GALERI FOTO (BARU) ---
    db.run(`CREATE TABLE IF NOT EXISTS gallery (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        image_path TEXT NOT NULL,
        caption TEXT,
        category TEXT DEFAULT 'kegiatan',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // --- SEED DATA AWAL (Agar menu & admin tidak kosong) ---
    const bcrypt = require('bcryptjs');
    
    // 1. Cek & Buat Admin Default
    const checkAdmin = db.exec("SELECT id FROM users WHERE username='admin_bmkg'");
    if (checkAdmin.length === 0) {
        const pw = bcrypt.hashSync('BmkgYogya2026!', 12);
        db.run("INSERT INTO users (username,password,nama_lengkap,email,nip,jabatan,role,unit_kerja) VALUES (?,?,?,?,?,?,?,?)", 
            ['admin_bmkg', pw, 'Administrator BMKG', 'admin@bmkg.go.id', '198601012024011001', 'Kepala Stasiun', 'admin', 'Staklim Yogyakarta']);
        console.log('✅ Admin default dibuat');
    }

    // 2. Cek & Isi Menu Awal
    const checkMenu = db.exec("SELECT id FROM menus LIMIT 1");
    if (checkMenu.length === 0) {
        console.log('ℹ️ Mengisi data awal menu navigasi...');
        const stmt = db.prepare("INSERT INTO menus (label, link, parent_id, sort_order) VALUES (?,?,?,?)");
        stmt.run('Home', '/', 0, 1);
        stmt.run('Profil', '#', 0, 2);
        stmt.run('Sejarah', '/profil#sejarah', 2, 1);
        stmt.run('Visi Misi', '/profil#visi-misi', 2, 2);
        stmt.run('Publikasi', '/publikasi', 0, 3);
        stmt.run('Iklim', '/iklim', 0, 4);
        stmt.finalize();
    }

    return db;
}

function saveDatabase() {
    if (db) {
        const data = db.export();
        const buffer = Buffer.from(data);
        fs.writeFileSync(process.env.DB_PATH || './database/bmkg.db', buffer);
    }
}

module.exports = { getDatabase, saveDatabase };