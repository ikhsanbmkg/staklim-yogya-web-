const jwt = require('jsonwebtoken');
const { getDatabase } = require('../config/database');

const verifyToken = async (req, res, next) => {
    const auth = req.headers['authorization'];
    if (!auth || !auth.startsWith('Bearer ')) {
        return res.status(401).json({ success: false, message: 'Token tidak ditemukan' });
    }
    try {
        const decoded = jwt.verify(auth.split(' ')[1], process.env.JWT_SECRET);
        const db = await getDatabase();
        const userResult = db.exec(`SELECT id, username, role, is_active FROM users WHERE id=${decoded.id}`);
        
        if (!userResult[0] || userResult[0].values.length === 0) {
            return res.status(401).json({ success: false, message: 'Akun tidak aktif' });
        }
        
        const userData = userResult[0].values[0];
        req.user = { id: userData[0], username: userData[1], role: userData[2] };
        next();
    } catch (e) {
        return res.status(403).json({ success: false, message: 'Token tidak valid' });
    }
};

const isAdmin = (req, res, next) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ success: false, message: 'Hanya admin' });
    }
    next();
};

const isEditor = (req, res, next) => {
    if (!['admin', 'editor'].includes(req.user.role)) {
        return res.status(403).json({ success: false, message: 'Akses ditolak' });
    }
    next();
};

module.exports = { verifyToken, isAdmin, isEditor };