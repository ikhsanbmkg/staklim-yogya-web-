const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const hpp = require('hpp');
const xss = require('xss-clean');
const mongoSanitize = require('mongo-sanitize');

const helmetConfig = helmet({
    contentSecurityPolicy: { 
        directives: { 
            defaultSrc: ["'self'"], 
            scriptSrc: ["'self'", "'unsafe-inline'"], 
            styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"], 
            fontSrc: ["'self'", "https://fonts.gstatic.com"], 
            imgSrc: ["'self'", "data:", "https:"], 
            connectSrc: ["'self'"], 
            frameSrc: ["'none'"], 
            objectSrc: ["'none'"] 
        } 
    },
    crossOriginEmbedderPolicy: true, 
    crossOriginOpenerPolicy: true, 
    crossOriginResourcePolicy: { policy: "same-origin" },
    hsts: { maxAge: 31536000, includeSubDomains: true, preload: true }, 
    frameguard: { action: 'deny' }, 
    noSniff: true, 
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' }
});

const apiLimiter = rateLimit({ 
    windowMs: 15 * 60 * 1000, 
    max: 50, 
    message: { success: false, message: 'Terlalu banyak permintaan' }, 
    standardHeaders: true 
});

const loginLimiter = rateLimit({ 
    windowMs: 15 * 60 * 1000, 
    max: 5, 
    message: { success: false, message: 'Terlalu banyak percobaan login' } 
});

const sanitizeInput = (req, res, next) => {
    if (req.body) req.body = mongoSanitize(req.body);
    if (req.query) req.query = mongoSanitize(req.query);
    next();
};

const requestLogger = (req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl} | IP:${req.ip}`);
    next();
};

module.exports = { 
    helmetConfig, 
    apiLimiter, 
    loginLimiter, 
    hppProtection: hpp(), 
    xssClean: xss(), 
    sanitizeInput, 
    requestLogger 
};