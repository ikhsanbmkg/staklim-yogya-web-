const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        let p = './uploads';
        if (file.fieldname === 'publication') p += '/publications';
        else if (file.fieldname === 'gallery') p += '/gallery';
        else p += '/others';
        cb(null, p);
    },
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname).toLowerCase();
        cb(null, Date.now() + '-' + Math.round(Math.random() * 1E9) + '-' + file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_').substring(0, 50));
    }
});

const fileFilter = (req, file, cb) => {
    const allowed = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'image/jpeg', 'image/png', 'image/gif'];
    const ext = ['.pdf', '.doc', '.docx', '.jpg', '.jpeg', '.png', '.gif'];
    if (allowed.includes(file.mimetype) && ext.includes(path.extname(file.originalname).toLowerCase())) {
        cb(null, true);
    } else {
        cb(new Error('Tipe file tidak diizinkan'), false);
    }
};

module.exports = multer({ storage, fileFilter, limits: { fileSize: 5 * 1024 * 1024, files: 3 } });