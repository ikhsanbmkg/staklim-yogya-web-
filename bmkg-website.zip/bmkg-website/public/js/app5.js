// public/js/app.js

document.addEventListener('DOMContentLoaded', () => {
    
    // 1. Update Jam Real-time WIB
    function updateClock() {
        const now = new Date();
        const options = { 
            timeZone: 'Asia/Jakarta', 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit', 
            hour12: false 
        };
        const timeString = now.toLocaleTimeString('id-ID', options);
        const clockEl = document.getElementById('clock-wib');
        if (clockEl) clockEl.textContent = timeString;
    }

    updateClock();
    setInterval(updateClock, 1000);

    // 2. Inisialisasi Kalender Dinamis
    function initCalendar() {
        const calendarContainer = document.querySelector('.cal-grid');
        if (!calendarContainer) return;

        const now = new Date();
        const currentDay = now.getDate(); 
        
        // Hapus tanggal lama kecuali header hari
        const headers = Array.from(calendarContainer.querySelectorAll('.cal-day-name'));
        calendarContainer.innerHTML = '';
        headers.forEach(h => calendarContainer.appendChild(h));

        // Generate tanggal 1-30/31
        const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
        
        for (let i = 1; i <= daysInMonth; i++) {
            const dateEl = document.createElement('div');
            dateEl.className = 'cal-date';
            dateEl.textContent = i;
            
            // Tandai hari ini
            if (i === currentDay) {
                dateEl.classList.add('today');
            }
            
            calendarContainer.appendChild(dateEl);
        }
    }
    
    initCalendar();

    // 3. Data Terjemahan ID/ENG
    const dict = {
        id: {
            header_org: "BADAN METEOROLOGI KLIMATOLOGI DAN GEOFISIKA",
            header_station: "Stasiun Klimatologi Yogyakarta",
            search_placeholder: "Cari data, berita...",
            nav_home: "Home", nav_profile: "Profil", nav_history: "Sejarah", nav_vision: "Visi dan Misi",
            nav_tasks: "Tugas Pokok", nav_structure: "Struktur Organisasi", nav_tools: "Alat Pengamatan BMKG",
            nav_map: "Peta Persebaran Pos Kerjasama", nav_publication: "Publikasi", nav_news: "Berita Terkini",
            nav_articles: "Artikel Ilmiah", nav_bulletin: "Bulletin Iklim", nav_warning: "Peringatan Dini",
            nav_rain: "Curah Hujan", nav_cyclone: "Siklon Tropis", nav_wave: "Gelombang Tinggi",
            nav_rob: "Banjir Pesisir (Rob)", nav_drought: "Kekeringan Meteorologis", nav_tsunami: "Tsunami",
            nav_weather: "Cuaca", nav_forecast: "Prakiraan Cuaca", nav_radar: "Citra Radar", nav_satellite: "Citra Satelit",
            nav_climate: "Iklim", nav_clim_warn: "Peringatan Dini Iklim", nav_clim_fore: "Prakiraan Iklim",
            nav_analysis: "Analisis Iklim", nav_normal_rain: "Normal Hujan Bulanan", nav_normal_season: "Normal Musim",
            nav_extreme: "Iklim Ekstrem", nav_kaleidoscope: "Kaleidoskop Iklim", nav_hydro: "Hidrometeorologi (SIH3)",
            nav_air: "Kualitas Udara", nav_pm25: "PM 2.5", nav_rain_chem: "Kimia Air Hujan",
            nav_service: "Pelayanan Data", nav_maklumat: "Maklumat Pelayanan", nav_online: "Data Online BMKG",
            nav_portal: "Portal Pelayanan Data", nav_survey: "Survei", nav_complaint: "Laporan Pengaduan",
            hero_title: "Informasi Iklim & Klimatologi Terpercaya untuk D.I. Yogyakarta",
            hero_desc: "Menyediakan data iklim historis, prakiraan musim, dan analisis klimatologi akurat untuk mendukung pembangunan berkelanjutan dan mitigasi bencana.",
            btn_data: "Lihat Data Iklim", btn_request: "Ajukan Permohonan", radar_label: "RADAR CUACA DIY",
            dash_req_title: "Jumlah Permohonan Layanan", dash_pop_title: "Layanan Terpopuler", dash_year: "Tahun 2026",
            pop_1: "Informasi Meteorologi untuk Keperluan Klaim Asuransi", pop_2: "Informasi Cuaca untuk Pelayaran (Analisis)",
            pop_3: "Informasi Meteorologi untuk Keperluan Klaim Asuransi", pop_4: "Kejadian Petir", pop_5: "Informasi Geofisika untuk Keperluan Klaim Asuransi",
            cal_month: "November 2026", dash_stat_title: "Statistik Pengunjung", dash_realtime: "Realtime",
            stat_online: "Online", stat_today: "Hari ini", stat_month: "Bulan ini", stat_year: "Tahun ini", stat_total: "Total",
            skm_title: "Survei Kepuasan Masyarakat (SKM) 2026", skm_good: "BAIK", skm_respondents: "114 Responden",
            skm_req: "Persyaratan", skm_proc: "Prosedur", skm_time: "Waktu Pelayanan", skm_cost: "Biaya/Tarif",
            skm_prod: "Produk Spesifikasi", skm_comp: "Kompetensi", skm_behav: "Perilaku", skm_handle: "Penanganan Pengaduan", skm_trend: "Tren Nilai SKM 5 Tahun",
            pr_label: "Siaran Pers Resmi", pr_title: "Staklim Yogyakarta Perkuat Komitmen Zona Integritas Menuju WBK",
            pr_desc: "Stasiun Klimatologi Yogyakarta secara resmi meluncurkan pembaruan website institusi sebagai wujud nyata akuntabilitas dan transparansi dalam pembangunan Zona Integritas (ZI) menuju Wilayah Bebas Korupsi (WBK).",
            btn_readmore: "Baca Selengkapnya", service_title: "Layanan Unggulan Kami",
            service_desc: "Akses informasi klimatologi terlengkap dengan standar kualitas internasional",
            srv_1_title: "Prakiraan Musim Hujan", srv_1_desc: "Prediksi onset, peak, dan end musim hujan serta estimasi curah hujan per zona di D.I. Yogyakarta.",
            srv_2_title: "Data Iklim Historis", srv_2_desc: "Arsip data iklim harian, bulanan, dan tahunan dari stasiun pengamatan otomatis maupun manual.",
            srv_3_title: "Analisis Iklim & Cuaca", srv_3_desc: "Laporan analisis tren iklim, anomali cuaca, dan kajian dampak perubahan iklim untuk wilayah lokal.",
            srv_4_title: "Peringatan Dini", srv_4_desc: "Informasi dini mengenai potensi bahaya cuaca ekstrem, banjir, kekeringan, dan bencana hidrometeorologi lainnya.",
            news_title: "Berita & Informasi Terkini", news_desc: "Update terbaru seputar kegiatan dan komitmen pelayanan publik",
            badge_zi: "Zona Integritas", news_1_title: "Peluncuran Website Modern & Komitmen Menuju WBK", news_1_desc: "Staklim Yogyakarta meluncurkan website resmi baru sebagai wujud transparansi dan akuntabilitas...",
            badge_season: "Prakiraan Musim", news_2_title: "Ekspose Prediksi Musim Hujan 2026/2027 D.I Yogyakarta", news_2_desc: "BMKG Staklim Yogyakarta menggelar ekspose prediksi musim hujan tahun 2026/2027...",
            badge_tech: "Teknologi", news_3_title: "Pemeliharaan Rutin Alat Observasi Otomatis (AWS)", news_3_desc: "Tim teknis BMKG Staklim Yogyakarta melakukan kalibrasi dan pemeliharaan berkala pada alat Automatic Weather Station untuk menjaga akurasi data...",
            badge_edu: "Edukasi", news_4_title: "Sosialisasi Mitigasi Kekeringan untuk Petani Lokal", news_4_desc: "Kegiatan sosialisasi penggunaan data iklim untuk optimalisasi pola tanam bagi petani...",
            footer_station: "Stasiun Klimatologi Yogyakarta", footer_agency: "Badan Meteorologi Klimatologi dan Geofisika<br>Kelas II D.I. Yogyakarta",
            footer_links: "Tautan Cepat", link_about: "Tentang Kami", link_pub: "Publikasi & Jurnal", link_data: "Data Iklim Online", link_request: "Permohonan Data", link_gallery: "Galeri Kegiatan",
            footer_contact: "Kontak Kami", footer_hours: "Senin - Jumat: 08.00 - 16.00 WIB", footer_social: "Media Sosial", footer_social_desc: "Ikuti update terkini melalui kanal resmi kami",
            marquee_1: "WASPADA: Potensi hujan lebat disertai angin kencang di wilayah Sleman dan Bantul sore ini.",
            marquee_2: "INFO: Prakiraan Musim Hujan 2026/2027 telah dirilis. Silakan unduh dokumen lengkapnya di menu Publikasi.",
            marquee_3: "PENGUMUMAN: Pelayanan data klimatologi offline tutup sementara pada tanggal 20 November 2026 untuk pemeliharaan sistem.",
            marquee_4: "CURAH HUJAN: Curah hujan tertinggi hari ini tercatat di Pos Pengamatan Kaliurang sebesar 45mm/jam.",
            weather_sleman: "Berawan", weather_bantul: "Cerah Berawan", weather_gunungkidul: "Cerah",
            weather_kulonprogo: "Hujan Ringan", weather_yogyakarta: "Berawan Tebal"
        },
        eng: {
            header_org: "METEOROLOGY, CLIMATOLOGY AND GEOPHYSICS AGENCY",
            header_station: "Yogyakarta Climatological Station",
            search_placeholder: "Search data, news...",
            nav_home: "Home", nav_profile: "Profile", nav_history: "History", nav_vision: "Vision & Mission",
            nav_tasks: "Main Tasks", nav_structure: "Organization Structure", nav_tools: "BMKG Observation Tools",
            nav_map: "Cooperation Post Distribution Map", nav_publication: "Publication", nav_news: "Latest News",
            nav_articles: "Scientific Articles", nav_bulletin: "Climate Bulletin", nav_warning: "Early Warning",
            nav_rain: "Rainfall", nav_cyclone: "Tropical Cyclone", nav_wave: "High Waves",
            nav_rob: "Coastal Flooding (Rob)", nav_drought: "Meteorological Drought", nav_tsunami: "Tsunami",
            nav_weather: "Weather", nav_forecast: "Weather Forecast", nav_radar: "Radar Imagery", nav_satellite: "Satellite Imagery",
            nav_climate: "Climate", nav_clim_warn: "Climate Early Warning", nav_clim_fore: "Climate Forecast",
            nav_analysis: "Climate Analysis", nav_normal_rain: "Monthly Rainfall Normal", nav_normal_season: "Seasonal Normal",
            nav_extreme: "Extreme Climate", nav_kaleidoscope: "Climate Kaleidoscope", nav_hydro: "Hydrometeorology (SIH3)",
            nav_air: "Air Quality", nav_pm25: "PM 2.5", nav_rain_chem: "Rainwater Chemistry",
            nav_service: "Data Service", nav_maklumat: "Service Information", nav_online: "BMKG Online Data",
            nav_portal: "Data Service Portal", nav_survey: "Survey", nav_complaint: "Complaint Report",
            hero_title: "Trusted Climate & Climatology Information for D.I. Yogyakarta",
            hero_desc: "Providing historical climate data, seasonal forecasts, and accurate climatological analysis to support sustainable development and disaster mitigation.",
            btn_data: "View Climate Data", btn_request: "Submit Request", radar_label: "DIY WEATHER RADAR",
            dash_req_title: "Number of Service Requests", dash_pop_title: "Most Popular Services", dash_year: "Year 2026",
            pop_1: "Meteorological Information for Insurance Claims", pop_2: "Weather Information for Navigation (Analysis)",
            pop_3: "Meteorological Information for Insurance Claims", pop_4: "Lightning Events", pop_5: "Geophysical Information for Insurance Claims",
            cal_month: "November 2026", dash_stat_title: "Visitor Statistics", dash_realtime: "Realtime",
            stat_online: "Online", stat_today: "Today", stat_month: "This Month", stat_year: "This Year", stat_total: "Total",
            skm_title: "Community Satisfaction Survey (CSS) 2026", skm_good: "GOOD", skm_respondents: "114 Respondents",
            skm_req: "Requirements", skm_proc: "Procedures", skm_time: "Service Time", skm_cost: "Cost/Tariff",
            skm_prod: "Product Specification", skm_comp: "Competence", skm_behav: "Behavior", skm_handle: "Complaint Handling", skm_trend: "5-Year CSS Value Trend",
            pr_label: "Official Press Release", pr_title: "Staklim Yogyakarta Strengthens Integrity Zone Commitment Towards WBK",
            pr_desc: "Yogyakarta Climatological Station officially launches the institutional website renewal as a tangible form of accountability and transparency in building the Integrity Zone (ZI) towards Corruption-Free Area (WBK).",
            btn_readmore: "Read More", service_title: "Our Featured Services",
            service_desc: "Access the most complete climatological information with international quality standards",
            srv_1_title: "Rainy Season Forecast", srv_1_desc: "Prediction of onset, peak, and end of rainy season and rainfall estimation per zone in D.I. Yogyakarta.",
            srv_2_title: "Historical Climate Data", srv_2_desc: "Archive of daily, monthly, and annual climate data from automatic and manual observation stations.",
            srv_3_title: "Climate & Weather Analysis", srv_3_desc: "Reports on climate trends, weather anomalies, and climate change impact studies for the local region.",
            srv_4_title: "Early Warning", srv_4_desc: "Early information regarding potential extreme weather hazards, floods, droughts, and other hydrometeorological disasters.",
            news_title: "Latest News & Information", news_desc: "Latest updates on activities and public service commitments",
            badge_zi: "Integrity Zone", news_1_title: "Modern Website Launch & Commitment Towards WBK", news_1_desc: "Staklim Yogyakarta launches a new official website as a form of transparency and accountability...",
            badge_season: "Seasonal Forecast", news_2_title: "Exposure of Rainy Season Prediction 2026/2027 D.I Yogyakarta", news_2_desc: "BMKG Staklim Yogyakarta holds an exposure of rainy season prediction for 2026/2027...",
            badge_tech: "Technology", news_3_title: "Routine Maintenance of Automatic Observation Tools (AWS)", news_3_desc: "Technical team performs calibration and maintenance of AWOS tools to maintain data accuracy...",
            badge_edu: "Education", news_4_title: "Drought Mitigation Socialization for Local Farmers", news_4_desc: "Socialization activity on using climate data for optimizing planting patterns for farmers...",
            footer_station: "Yogyakarta Climatological Station", footer_agency: "Meteorology, Climatology and Geophysics Agency<br>Class II D.I. Yogyakarta",
            footer_links: "Quick Links", link_about: "About Us", link_pub: "Publications & Journals", link_data: "Online Climate Data", link_request: "Data Request", link_gallery: "Activity Gallery",
            footer_contact: "Contact Us", footer_hours: "Monday - Friday: 08.00 - 16.00 WIB", footer_social: "Social Media", footer_social_desc: "Follow the latest updates through our official channels",
            marquee_1: "WARNING: Potential heavy rain accompanied by strong winds in Sleman and Bantul areas this afternoon.",
            marquee_2: "INFO: Rainy Season Forecast 2026/2027 has been released. Please download the full document in the Publication menu.",
            marquee_3: "ANNOUNCEMENT: Offline climatological data service is temporarily closed on November 20, 2026 for system maintenance.",
            marquee_4: "RAINFALL: The highest rainfall recorded today at Kaliurang Observation Post was 45mm/hour.",
            weather_sleman: "Cloudy", weather_bantul: "Partly Cloudy", weather_gunungkidul: "Clear",
            weather_kulonprogo: "Light Rain", weather_yogyakarta: "Thick Clouds"
        }
    };

    let lang = 'id';

    // Fungsi Ganti Bahasa
    window.toggleLang = function() {
        lang = (lang === 'id') ? 'eng' : 'id';
        
        // Update teks elemen
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            if (dict[lang][key]) el.textContent = dict[lang][key];
        });

        // Update placeholder input
        document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
            const key = el.getAttribute('data-i18n-placeholder');
            if (dict[lang][key]) el.placeholder = dict[lang][key];
        });

        // Toggle class slider bahasa
        const toggleBtn = document.getElementById('langToggle');
        if (toggleBtn) toggleBtn.classList.toggle('eng');
    };

    // Bind event click ke tombol bahasa
    const btnLang = document.getElementById('langToggle');
    if (btnLang) btnLang.addEventListener('click', toggleLang);

    // 4. Fungsi Ganti Ukuran Font (Fitur Baru)
    window.setFontSize = function(size) {
        const toggle = document.getElementById('fontSizeToggle');
        const root = document.documentElement;
        
        if (size === 'large') {
            toggle.classList.add('large-mode');
            // Naikkan ukuran font global sebesar 15%
            root.style.fontSize = '115%'; 
        } else {
            toggle.classList.remove('large-mode');
            // Kembali ke ukuran normal
            root.style.fontSize = '100%';
        }
    };
});