// public/js/lang-toggle.js
const translations = {
    id: { search_placeholder: "Cari data, berita...", nav_home: "Home", /* ...isi lengkap lainnya... */ },
    eng: { search_placeholder: "Search data, news...", nav_home: "Home", /* ...isi lengkap lainnya... */ }
};

let currentLang = 'id';

function toggleLanguage() {
    const toggle = document.getElementById('langToggle');
    if (!toggle) return;
    
    currentLang = currentLang === 'id' ? 'eng' : 'id';
    toggle.classList.toggle('eng');
    applyTranslation();
}

function applyTranslation() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (translations[currentLang][key]) {
            el.textContent = translations[currentLang][key];
        }
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
        const key = el.getAttribute('data-i18n-placeholder');
        if (translations[currentLang][key]) {
            el.placeholder = translations[currentLang][key];
        }
    });
}