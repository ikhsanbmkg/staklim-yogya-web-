const express = require('express');
const router = express.Router();
const { getDatabase, saveDatabase } = require('../config/database');
const { verifyToken, isAdmin } = require('../middleware/auth');

// Proteksi: Hanya admin login yang bisa akses
router.use(verifyToken, isAdmin);

// --- GET ALL MENUS ---
router.get('/menus', async (req, res) => {
    try {
        const db = await getDatabase();
        const result = db.exec("SELECT * FROM menus ORDER BY sort_order ASC");
        const menus = result[0] ? result[0].values.map(row => ({
            id: row[0], label: row[1], link: row[2], parent_id: row[3], sort_order: row[4], is_active: row[5]
        })) : [];
        res.json({ success: true, data: menus });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// --- ADD NEW MENU ---
router.post('/menus', async (req, res) => {
    try {
        const { label, link, parent_id, sort_order } = req.body;
        const db = await getDatabase();
        db.run("INSERT INTO menus (label, link, parent_id, sort_order) VALUES (?,?,?,?)", 
            [label, link || '#', parent_id || 0, sort_order || 0]);
        saveDatabase();
        res.json({ success: true, message: 'Menu berhasil ditambahkan' });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// --- ADD PUBLICATION / BERITA ---
router.post('/publications', async (req, res) => {
    try {
        const { judul, slug, kategori, ringkasan, konten, status } = req.body;
        const db = await getDatabase();
        db.run(`INSERT INTO publications (judul, slug, kategori, ringkasan, konten, status, author_id, published_at) 
                VALUES (?,?,?,?,?,?,?, datetime('now'))`,
            [judul, slug, kategori, ringkasan, konten, status || 'draft', req.user.id]);
        saveDatabase();
        res.json({ success: true, message: 'Berita berhasil disimpan' });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// --- ADD CLIMATE DATA ---
router.post('/climate', async (req, res) => {
    try {
        const { tanggal, stasiun, suhu_min, suhu_max, curah_hujan } = req.body;
        const db = await getDatabase();
        db.run(`INSERT INTO climate_data (tanggal, stasiun, suhu_min, suhu_max, curah_hujan, entered_by) 
                VALUES (?,?,?,?,?,?)`,
            [tanggal, stasiun, suhu_min, suhu_max, curah_hujan, req.user.id]);
        saveDatabase();
        res.json({ success: true, message: 'Data iklim berhasil disimpan' });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

module.exports = router;