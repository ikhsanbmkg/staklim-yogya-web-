const express = require('express');
const router = express.Router();

// Contoh route login sederhana agar tidak error
router.post('/login', (req, res) => {
    res.json({ success: true, message: 'Fitur login akan segera hadir' });
});

module.exports = router;