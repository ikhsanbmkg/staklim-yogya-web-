const express = require('express');
const router = express.Router();

// Route sementara agar tidak error
router.get('/', (req, res) => {
    res.json({ success: true, message: 'Halaman publikasi' });
});

module.exports = router;