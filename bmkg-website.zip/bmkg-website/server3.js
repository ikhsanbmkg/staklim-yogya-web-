// server.js - Server Utama Staklim Yogyakarta
const express = require('express');
const path = require('path');
const helmet = require('helmet');

const app = express();
const PORT = 3000;

// --- KONFIGURASI KEAMANAN & MIDDLEWARE ---
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com"],
            fontSrc: ["'self'", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com"],
            scriptSrc: ["'self'"], // Memaksa JS eksternal (Anti-XSS)
            imgSrc: ["'self'", "data:", "https:"],
            connectSrc: ["'self'"]
        }
    },
    crossOriginEmbedderPolicy: false // Diperlukan untuk beberapa fitur browser modern
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// --- ROUTING UTAMA ---
app.get('/', (req, res) => {
    const now = new Date();
    
    // Format Tanggal Lengkap (Rabu, 18 November 2026)
    const dateOptions = { 
        weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
        timeZone: 'Asia/Jakarta' 
    };
    const currentDate = now.toLocaleDateString('id-ID', dateOptions).toUpperCase();

    // Format Jam Awal (akan diupdate real-time oleh JS klien)
    const timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false, timeZone: 'Asia/Jakarta' };
    const clockWib = now.toLocaleTimeString('id-ID', timeOptions);

    res.render('home', { currentDate, clockWib });
});

// --- JALANKAN SERVER DENGAN BANNER PROFESIONAL ---
app.listen(PORT, () => {
    console.log('\n' + '='.repeat(50));
    console.log('🚀  SERVER STAKLIM YOGYAKARTA BERJALAN');
    console.log('   http://localhost:' + PORT);
    console.log('='.repeat(50));
    console.log('✅  STATUS: SERVER RUNNING & READY');
    console.log('🛡️  SECURITY: HELMET.JS ACTIVE (CSP ENABLED)');
    console.log('⚙️  RUNTIME: NODE.JS ' + process.version + ' (LTS)');
    console.log('='.repeat(50) + '\n');
});